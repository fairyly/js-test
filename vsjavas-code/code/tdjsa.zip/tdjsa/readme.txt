Workspace for

Test-Driving JavaScript Applications
Rapid, Confident, Maintainable Code
------------------------------------------------------------------------------
Greetings,

This workspace contains pre-created projects, directories, and mostly empty files that you can edit while practicing the examples in the book.

Thank you for reading the book and practicing along.

Venkat Subramaniam
------------------------------------------------------------------------------

Copyrights apply to this source code. You may use the source code in your own projects, however the source code may not be used to create training material, courses, books, articles, and the like. We make no guarantees that this source code is fit for any purpose.